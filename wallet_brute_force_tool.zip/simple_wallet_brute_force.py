#!/usr/bin/env python3
"""
Cryptocurrency Wallet Brute Force Tool
Generates BIP-39 seed phrases and checks for balances across multiple blockchain networks.
"""
import os
import sys
import time
import random
import logging
import argparse
import requests
from datetime import datetime
from bip_utils import Bip39SeedGenerator, Bip44, Bip44Coins
from bip_utils.bip.bip39.bip39_mnemonic import Bip39MnemonicGenerator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("brute_force_log.txt")
    ]
)

# Constants
DEFAULT_CHECK_INTERVAL = 0.5
DEFAULT_REPORT_INTERVAL = 10
DEFAULT_NETWORKS = ["BTC"]

# API Configuration
API_CONFIG = {
    'BTC': {
        'url': 'https://blockchain.info/balance?active={address}',
        'divisor': 100000000,  # 1 BTC = 100,000,000 satoshis
        'symbol': 'BTC',
        'key': None
    },
    'ETH': {
        'url': 'https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest',
        'divisor': 1000000000000000000,  # 1 ETH = 10^18 wei
        'symbol': 'ETH',
        'key': None
    },
    'BSC': {
        'url': 'https://api.bscscan.com/api?module=account&action=balance&address={address}&tag=latest',
        'divisor': 1000000000000000000,  # 1 BNB = 10^18 wei
        'symbol': 'BNB',
        'key': None
    },
    'TRX': {
        'url': 'https://api.trongrid.io/v1/accounts/{address}',
        'divisor': 1000000,  # 1 TRX = 10^6 sun
        'symbol': 'TRX',
        'key': None
    }
}

def read_keywords(filename):
    """Read BIP-39 keywords from a file."""
    try:
        with open(filename, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        logging.error(f"Keywords file '{filename}' not found. Creating a sample file...")
        # Create a sample file with the first 20 BIP-39 words
        sample_words = [
            "abandon", "ability", "able", "about", "above", 
            "absent", "absorb", "abstract", "absurd", "abuse",
            "access", "accident", "account", "accuse", "achieve", 
            "acid", "acoustic", "acquire", "across", "act"
        ]
        with open(filename, 'w') as f:
            for word in sample_words:
                f.write(word + "\n")
        logging.warning(f"Created a sample file with {len(sample_words)} words. For proper usage, please replace with a complete BIP-39 wordlist.")
        return sample_words
    except Exception as e:
        logging.error(f"Error reading keywords file: {str(e)}")
        return []

def generate_random_addresses(keywords, count=12):
    """
    Generate a random BIP-39 mnemonic with valid checksum and derive addresses.
    
    Args:
        keywords (list): List of BIP-39 keywords to choose from
        count (int): Number of words in the mnemonic (12, 15, 18, 21, or 24)
    
    Returns:
        dict: Dictionary containing the mnemonic and derived addresses
    """
    try:
        # Instead of random word selection, use the BIP-39 generator
        # to create a valid mnemonic with proper checksum
        try:
            # Generate a valid BIP-39 mnemonic directly
            mnemonic = Bip39MnemonicGenerator().FromWordsNumber(count).ToStr()
        except (ImportError, AttributeError):
            # Fallback to manual generation if the direct method fails
            # This is less efficient but still works
            entropy_bits = {
                12: 128,
                15: 160,
                18: 192,
                21: 224,
                24: 256
            }.get(count, 128)
            
            # Generate random entropy (in bytes)
            entropy_bytes = bytes(random.getrandbits(8) for _ in range(entropy_bits // 8))
            
            # Get mnemonic from the entropy
            mnemonic = Bip39MnemonicGenerator().FromEntropy(entropy_bytes).ToStr()
            
        # Generate seed from mnemonic
        seed = Bip39SeedGenerator(mnemonic).Generate()
        addresses = {}
        
        # BTC address
        btc_wallet = Bip44.FromSeed(seed, Bip44Coins.BITCOIN).DeriveDefaultPath()
        addresses['BTC'] = btc_wallet.PublicKey().ToAddress()
        
        # ETH address (also used for BSC)
        eth_wallet = Bip44.FromSeed(seed, Bip44Coins.ETHEREUM).DeriveDefaultPath()
        eth_address = eth_wallet.PublicKey().ToAddress()
        addresses['ETH'] = eth_address
        addresses['BSC'] = eth_address  # BSC uses same address format as ETH
        
        # TRX address
        try:
            trx_wallet = Bip44.FromSeed(seed, Bip44Coins.TRON).DeriveDefaultPath()
            addresses['TRX'] = trx_wallet.PublicKey().ToAddress()
        except Exception as e:
            # If TRX derivation fails, use a placeholder
            logging.debug(f"Error deriving TRX address: {str(e)}")
            addresses['TRX'] = None
            
        return {
            "mnemonic": mnemonic,
            "addresses": addresses
        }
    except Exception as e:
        logging.debug(f"Error in mnemonic generation: {str(e)}")
        return None

def check_balance(network, address):
    """
    Check balance of a wallet address on a specific network.
    
    Args:
        network (str): Network symbol (BTC, ETH, BSC, TRX)
        address (str): Wallet address to check
        
    Returns:
        int: Balance in the smallest unit of the currency (satoshi, wei, etc.)
             Returns 0 if balance check fails or if address is None.
    """
    if address is None:
        return 0
        
    config = API_CONFIG.get(network)
    if not config:
        logging.error(f"Network {network} not supported")
        return 0
    
    url = config['url'].format(address=address)
    headers = {}
    if config['key']:
        if network == 'TRX':
            headers = {'TRON-PRO-API-KEY': config['key']}
        else:  # For ETH, BSC, potentially others
            url = f"{url}&apikey={config['key']}"
    
    try:
        response = requests.get(url, headers=headers)
        data = response.json()
        
        if network == "BTC":
            return data[address]['final_balance']
        elif network == "ETH" or network == "BSC":
            return int(data.get('result', 0))
        elif network == "TRX":
            # TRX API returns balance in a different format
            return int(data.get('data', [{}])[0].get('balance', 0))
        else:
            return 0
    except Exception as e:
        logging.error(f"Error checking {network} balance for {address}: {str(e)}")
        return 0

def format_balance(network, balance):
    """Format raw balance to human-readable form."""
    config = API_CONFIG.get(network, {})
    divisor = config.get('divisor', 1)
    symbol = config.get('symbol', network)
    
    if balance == 0:
        return f"0 {symbol}"
    
    formatted = balance / divisor
    return f"{formatted:.8f} {symbol}"

def save_findings(wallet_data, balances):
    """Save found wallets with balances to a file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mnemonic = wallet_data["mnemonic"]
    addresses = wallet_data["addresses"]
    
    with open("found_wallets.txt", "a") as f:
        f.write(f"=== WALLET FOUND: {timestamp} ===\n")
        f.write(f"Seed phrase: {mnemonic}\n")
        
        for network, address in addresses.items():
            if network in balances:
                f.write(f"{network} Address: {address}\n")
                f.write(f"{network} Balance: {format_balance(network, balances[network])}\n")
        
        f.write("\n")

def brute_force_process(keywords, target_networks, check_interval, report_interval):
    """
    Main brute force function to generate and check wallets using BIP-39/44 standards.
    
    Args:
        keywords (list): List of BIP-39 keywords to use
        target_networks (list): Networks to check for balances
        check_interval (float): Time to wait between API calls
        report_interval (int): How often to report statistics
    """
    attempts = 0
    valid_attempts = 0
    found_wallets = 0
    start_time = time.time()
    
    logging.info(f"Starting brute force process for networks: {', '.join(target_networks)}")
    logging.info(f"Loaded {len(keywords)} keywords")
    print(f"Press Ctrl+C to stop the process...")
    
    try:
        while True:
            attempts += 1
            
            # Generate wallet data - may be None if mnemonic is invalid
            wallet_data = generate_random_addresses(keywords)
            if wallet_data is None:
                # Skip invalid mnemonics
                continue
                
            valid_attempts += 1
            
            # Check balances
            balances = {}
            any_balance = False
            
            for network in target_networks:
                if network in wallet_data["addresses"]:
                    address = wallet_data["addresses"][network]
                    if address is not None:
                        balance = check_balance(network, address)
                        balances[network] = balance
                        
                        if balance > 0:
                            any_balance = True
                    
                    # Avoid rate limiting
                    time.sleep(check_interval)
            
            # Report if any balance is found
            if any_balance:
                found_wallets += 1
                
                logging.info("\n" + "="*50)
                logging.info("BALANCE FOUND!")
                logging.info(f"Seed phrase: {wallet_data['mnemonic']}")
                
                for network in target_networks:
                    if network in wallet_data["addresses"] and network in balances:
                        logging.info(f"{network} Address: {wallet_data['addresses'][network]}")
                        formatted_balance = format_balance(network, balances[network])
                        logging.info(f"{network} Balance: {formatted_balance}")
                
                logging.info("="*50)
                
                # Save to file
                save_findings(wallet_data, balances)
            
            # Report statistics periodically
            if valid_attempts % report_interval == 0:
                elapsed_time = time.time() - start_time
                rate = valid_attempts / elapsed_time if elapsed_time > 0 else 0
                
                found_text = f"{found_wallets} WALLETS FOUND! Check found_wallets.txt" if found_wallets > 0 else "No wallets found yet"
                print(f"\r[{valid_attempts:,} valid attempts] [Rate: {rate:.2f}/sec] [{found_text}]", end="")
                sys.stdout.flush()
                
                # Also log stats less frequently
                if valid_attempts % (report_interval * 5) == 0:
                    invalid_percent = ((attempts - valid_attempts) / attempts * 100) if attempts > 0 else 0
                    logging.info(f"Stats: {valid_attempts} valid attempts, {attempts} total attempts, {invalid_percent:.1f}% invalid, {found_wallets} found, {rate:.2f} attempts/sec")
                
    except KeyboardInterrupt:
        elapsed_time = time.time() - start_time
        rate = attempts / elapsed_time if elapsed_time > 0 else 0
        
        logging.info("\nStopping brute force process...")
        print("\n\nSession summary:")
        print(f"  Total attempts: {attempts:,}")
        print(f"  Wallets found: {found_wallets}")
        print(f"  Average rate: {rate:.2f} attempts/sec")
        print(f"  Elapsed time: {elapsed_time:.1f} seconds")
        if found_wallets > 0:
            print(f"  Found wallets saved to: found_wallets.txt")
    except Exception as e:
        logging.error(f"Error in brute force process: {str(e)}")

def main():
    """Main function to parse arguments and start the process."""
    parser = argparse.ArgumentParser(description='Cryptocurrency Wallet Brute Force Tool')
    parser.add_argument('--networks', nargs='+', default=DEFAULT_NETWORKS, 
                        help=f'Networks to check (e.g., BTC ETH). Default: {" ".join(DEFAULT_NETWORKS)}')
    parser.add_argument('--interval', type=float, default=DEFAULT_CHECK_INTERVAL,
                        help=f'Time to wait between API calls (default: {DEFAULT_CHECK_INTERVAL})')
    parser.add_argument('--report', type=int, default=DEFAULT_REPORT_INTERVAL,
                        help=f'How often to report statistics (default: {DEFAULT_REPORT_INTERVAL} attempts)')
    parser.add_argument('--keywords', type=str, default='keywords.txt',
                        help='Path to the file containing BIP-39 keywords (default: keywords.txt)')
    
    args = parser.parse_args()
    
    # Validate networks
    available_networks = list(API_CONFIG.keys())
    valid_networks = [n for n in args.networks if n in available_networks]
    
    if not valid_networks:
        print(f"No valid networks selected. Available networks: {', '.join(available_networks)}")
        return
    
    # Read keywords
    keywords = read_keywords(args.keywords)
    if not keywords:
        print("Failed to read keywords file and couldn't create a sample file.")
        return
    
    try:
        brute_force_process(keywords, valid_networks, args.interval, args.report)
    except KeyboardInterrupt:
        print("\nProcess stopped by user.")

if __name__ == "__main__":
    main()