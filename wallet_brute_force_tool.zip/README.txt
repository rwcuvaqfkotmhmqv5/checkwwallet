# Cryptocurrency Wallet Brute Force Tool

A Python-based cryptocurrency wallet brute-force tool that generates random BIP-39 seed phrases and checks balances across multiple blockchains.

## Features

- Generate random BIP-39 seed phrases using cryptographic standards
- Derive wallet addresses using BIP-44 HD wallet derivation paths
- Check balances on multiple networks
- Save found wallets with balances to a file
- Configurable API requests to avoid rate limiting
- Command-line interface with customizable options
