# Cryptocurrency Wallet Brute Force Tool

A Python-based cryptocurrency wallet brute-force tool that generates random BIP-39 seed phrases and checks balances across multiple blockchains.

## Features

- Generate random BIP-39 seed phrases using cryptographic standards
- Derive wallet addresses using BIP-44 HD wallet derivation paths
- Check balances on multiple networks:
  - Bitcoin (BTC)
  - Ethereum (ETH)
  - Binance Smart Chain (BSC)
  - Tron (TRX)
- Save found wallets with balances to a file
- Configurable API requests to avoid rate limiting
- Command-line interface with customizable options
- Statistical tracking of valid/invalid mnemonics

## Requirements

- Python 3.6 or higher
- Required Python packages:
  - `requests`
  - `bip-utils`

## Installation

1. Make sure you have Python installed on your system
2. Install the required packages:
   ```
   pip install requests bip-utils
   ```

## Usage

### Basic Usage

To start the brute force process with default options (checking Bitcoin only):

```
python simple_wallet_brute_force.py
```

### Command Line Options

The tool supports the following command-line options:

```
--networks: Networks to check (e.g., BTC ETH BSC TRX)
--interval: Time to wait between API calls (default: 0.5 seconds)
--report: How often to report statistics (default: 10 attempts)
--keywords: Path to the file containing BIP-39 keywords (default: keywords.txt)
```

Example:
```
python simple_wallet_brute_force.py --networks BTC ETH BSC --interval 1.0 --report 20
```

## API Keys (Optional)

For non-Bitcoin networks, you can enhance API functionality with free API keys:

1. For Ethereum: Get a free API key from [Etherscan](https://etherscan.io/apis)
2. For BSC: Get a free API key from [BscScan](https://bscscan.com/apis)
3. For Tron: Get a free API key from [TronGrid](https://www.trongrid.io/)

Add your API keys to the API_CONFIG section of the script to avoid rate limiting.

## Creating an Executable

If you want to package the tool as an executable file, follow these steps:

1. Install PyInstaller:
   ```
   pip install pyinstaller
   ```

2. Create the executable:
   ```
   pyinstaller --onefile simple_wallet_brute_force.py
   ```

3. The executable will be in the `dist` folder

### For Windows Users

To create a Windows executable, follow these steps:

1. Install PyInstaller: `pip install pyinstaller`
2. Open Command Prompt and navigate to the folder containing the script
3. Run: `pyinstaller --onefile simple_wallet_brute_force.py`
4. The executable will be in the `dist` folder

### For macOS/Linux Users

1. Install PyInstaller: `pip install pyinstaller`
2. Open Terminal and navigate to the folder containing the script
3. Run: `pyinstaller --onefile simple_wallet_brute_force.py`
4. The executable will be in the `dist` folder

## How It Works

This tool implements a BIP-39/44 compliant wallet generation process:

1. It randomly selects 12 words from the BIP-39 wordlist
2. Validates the mnemonic and generates a master seed
3. Derives addresses for different cryptocurrencies using BIP-44 paths
4. Checks the addresses for balances using blockchain APIs
5. Saves any wallets found with non-zero balances

The random generation process can create invalid mnemonics which are automatically filtered out, with statistics reported on the valid/invalid ratio.

## Disclaimer

This tool is for educational purposes only. Using it to attempt to gain unauthorized access to cryptocurrency wallets would be illegal and unethical. The probability of randomly generating a seed phrase that corresponds to a wallet with funds is astronomically low (approximately 1 in 2^128).